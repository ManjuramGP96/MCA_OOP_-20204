import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The Main class is the entry point for the Assembly system.
 * It initializes the system and provides interaction for the user.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Assembly assembly = new Assembly(scanner);
        assembly.my_Assemble();
        scanner.close();
    }
}
