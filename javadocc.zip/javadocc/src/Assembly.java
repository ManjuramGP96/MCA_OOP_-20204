import java.util.Scanner;

/**
 * The Assembly class extends the Mla class and provides an interface to interact with the legislative assembly,
 * including the legislature, government, house, and contact details.
 */
public class Assembly extends Mla {
    /**
     * Constructor to initialize the Assembly class with a Scanner for user input.
     *
     * @param scanner Scanner object for taking input from the user.
     */
    public Assembly(Scanner scanner) {
        super(scanner);
    }

    /**
     * Displays a main menu for interacting with the assembly system, including options to view the legislature, government, house, and contact information.
     */
    public void my_Assemble() {
        while (true) {
            System.out.println("1: The Legislature");
            System.out.println("2: The Government");
            System.out.println("3: The House");
            System.out.println("4: Contact Us");
            System.out.println("5: Exit");
            System.out.print("Enter your choice: ");
            if (scanner.hasNextInt()) {
                int menu = scanner.nextInt();
                scanner.nextLine();

                switch (menu) {
                    case 1 -> {
                        System.out.println("The Legislature:");
                        list_mla();
                    }
                    case 2 -> {
                        System.out.println("The Government:");
                        the_government();
                    }
                    case 3 -> {
                        System.out.println("The House:");
                        manageBills();
                    }
                    case 4 -> {
                        System.out.println("Contact Us:");
                        System.out.println("Email: info@goa.gov.in\n");
                    }
                    case 5 -> {
                        System.out.println("Exiting...");
                        return;
                    }
                    default -> System.out.println("Invalid choice");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            }
        }
    }
}
