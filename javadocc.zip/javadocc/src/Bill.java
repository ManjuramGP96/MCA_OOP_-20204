/**
 * The Bill class represents a legislative bill.
 * It contains information such as the title, description, and whether the bill has been passed.
 */
public class Bill {
    private String title;
    private String description;
    private boolean isPassed;

    /**
     * Constructor to initialize the Bill object with a title and description.
     *
     * @param title       The title of the bill.
     * @param description A brief description of the bill.
     */
    public Bill(String title, String description) {
        this.title = title;
        this.description = description;
        this.isPassed = false;
    }

    /**
     * Returns the title of the bill.
     *
     * @return The title of the bill.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Marks the bill as passed.
     */
    public void pass() {
        this.isPassed = true;
    }

    /**
     * Returns a string representation of the bill, including the title, description, and whether it has been passed.
     *
     * @return A string with the bill details.
     */
    @Override
    public String toString() {
        return "Title: " + title + "\nDescription: " + description + "\nPassed: " + (isPassed ? "Yes" : "No") + "\n";
    }
}
